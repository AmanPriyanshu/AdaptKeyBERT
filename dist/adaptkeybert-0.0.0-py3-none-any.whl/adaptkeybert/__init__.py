from adaptkeybert._model import KeyBERT

__version__ = "0.0.0"
__author__ = 'Aman Priyanshu'