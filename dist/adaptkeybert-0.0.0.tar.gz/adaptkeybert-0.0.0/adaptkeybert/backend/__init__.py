from ._base import BaseEmbedder

__all__ = ["BaseEmbedder"]
